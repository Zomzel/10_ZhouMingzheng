import numpy as np
import pandas as pd
import json

# 读取csv文件
# data = pd.read_csv('test.csv')
# df = pd.DataFrame(data)
data1 = pd.read_csv('nodes.csv')
data2 = pd.read_csv('links.csv')
nodes = pd.DataFrame(data1)
links = pd.DataFrame(data2)
#
# # 过滤
# 提取各部分实体的数据
# condition_1 = data1['type'] == 'company'
# condition_2 = data1['type'] == 'organization'
# condition_3 = data1['type'] == 'location'
# condition_4 = data1['type'] == 'person'
# condition_5 = data1['type'] == 'political_organization'
# condition_6 = data1['type'] == 'vessel'
# condition_7 = data1['type'] == 'event'
# condition_8 = data1['type'] == 'movement'
#
# company = data1[condition_1]
# organization = data1[condition_2]
# location = data1[condition_3]
# person = data1[condition_4]
# political_organization = data1[condition_5]
# vessel = data1[condition_6]
# event = data1[condition_7]
# movement = data1[condition_8]
#
# company.to_csv('company.csv', index=False)
# organization.to_csv('organization.csv', index=False)
# location.to_csv('location.csv', index=False)
# person.to_csv('person.csv', index=False)
# political_organization.to_csv('political_organization.csv', index=False)
# vessel.to_csv('vessel.csv', index=False)
# event.to_csv('event.csv', index=False)
# movement.to_csv('movement.csv', index=False)

#
#
# 抽样
# 加权抽样
# 定义权重列，一般节点权重为1，网络核心权重为5
# weights = df['to_level'].map({'一般节点': 1, '网络核心': 5})
nodes.insert(loc=5, column='weight', value=0)
weights = nodes['type'].map({'company': 100, 'organization': 100, 'location': 1,
                             'person': 100, 'political_organization': 50,
                             'vessel': 10, 'event': 1, 'movement': 1})
#
# # 采样比例20%，random_state为随机种子
# sample_1 = df.sample(frac=0.2, weights=weights, random_state=42)
# sample_1.to_csv('weighted_sampling.csv', index=False)
sample_1 = nodes.sample(frac=0.2, weights=weights, random_state=42)
sample_1.to_csv('nodes_weighted_sampling.csv', index=False)
#
#
# # 分层采样
# # 设置分层抽样的层级列
# stratify_by = 'to_level'
# # 定义抽样函数
# def stratified_sample(data):
#     return data.sample(frac=0.2, random_state=42)
#
# # groupby按照层级列进行分组，并使用apply方法应用采样函数
# sample_2 = df.groupby(stratify_by, group_keys=False).apply(stratified_sample)
# sample_2.to_csv('stratified_sampling.csv', index=False)

# 设置分层抽样的层级列
stratify_by = 'type'


# 定义抽样函数
def stratified_sample(data):
    return data.sample(frac=0.2, random_state=42)


# groupby按照层级列进行分组，并使用apply方法应用采样函数
sample_2 = nodes.groupby(stratify_by, group_keys=False).apply(stratified_sample)
sample_2.to_csv('nodes_stratified_sampling.csv', index=False)
#
#
# # 随机抽样
# sample_3 = df.sample(frac=0.2, random_state=42)
# sample_3.to_csv('random_sampling.csv', index=False)
sample_3 = nodes.sample(frac=0.2, random_state=42)
sample_3.to_csv('nodes_random_sampling.csv', index=False)
#
#
# # 系统抽样
step = 5


def systematic_sampling(df, step):
    # 创建索引数组，包含了以0开始、以len(df结束)，步长为step的索引
    indexes = np.arange(0, len(df), step=step)
    ans = df.iloc[indexes]
    return ans


#
# sample_4 = systematic_sampling(df, step)
# sample_4.to_csv('systematic_sampling.csv', index=False)
sample_4 = systematic_sampling(nodes, step)
sample_4.to_csv('nodes_systematic_sampling.csv', index=False)


#
#


# # 整群抽样
def cluster_sample(data):
    return data.sample(n=1, random_state=42)  # 从每个群组中随机选择一个样本


#
# # 按照to_city列的值进行分组，然后应用抽样函数
# sample_5 = df.groupby('to_city').apply(cluster_sample)
# sample_5.to_csv('cluster_sampling.csv', index=False)
sample_5 = nodes.groupby('type').apply(cluster_sample)
sample_5.to_csv('nodes_cluster_sampling.csv', index=False)

# with open('MC1.json', encoding='utf-8') as f:
#     data = json.load(f)
#
#
# nodes = pd.DataFrame(data['nodes'])
# links = pd.DataFrame(data['links'])
# 此时nodes和links为dataFrame类型

# print(nodes.head(5))
# print(links.head(5))
#
# nodes.to_csv('nodes.csv')
# links.to_csv('links.csv')
